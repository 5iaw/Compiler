import java.util.*;

public class LL1Parser {

    public int idx;
    private Stack<String> stack;
    private HashMap<String, HashMap<String, List<String>>> parsingTable;
    public List<Token.TokenEntry> table;
    public int max_len;
    public Token.TokenEntry token;
    public List<String> declared_variables;

    public Token.TokenEntry entry;


    private void generate_stack() {
        stack = new Stack<>();
        stack.push("$");
        stack.push("S");
        //printStack(stack, "initial");
    }

    public static List<String> generateRule(String inputString) {
        String[] tokenArray = inputString.split("\\s+");
        //System.out.println(tokenArray[1]);
        return Arrays.asList(tokenArray);
    }

    private void generate_parsingTable() {
        parsingTable = new HashMap<>();

        List<String> S = generateRule("BEGIN_BLOCK BEGIN_STMT");

        List<String> BEGIN_BLOCK1 = generateRule("program identifier");

        List<String> BEGIN_STMT1 = generateRule("begin STMTS end");

        List<String> STMTS1 = generateRule("STMT STMTS_P");

        List<String> STMTS_P1 = generateRule("STMTS");
        List<String> STMTS_P2 = generateRule("");


        List<String> STMT1 = generateRule("DECLARATION_LIST");
        List<String> STMT2 = generateRule("IF_STMT");
        List<String> STMT3 = generateRule("PRINT_STMT");
        List<String> STMT4 = generateRule("WHILE_STMT");
        List<String> STMT5 = generateRule("FOR_STMT");
        List<String> STMT6 = generateRule("BREAK_STMT");


        List<String> TYPE1 = generateRule("int");
        List<String> TYPE2 = generateRule("integer");


        List<String> DECLARATION_LIST1 = generateRule("DECLARATION DECLARATION_LIST_P");
        List<String> DECLARATION_LIST2 = generateRule(""); // epsilon (empty)

        List<String> DECLARATION_LIST_P1 = generateRule(", DECLARATION DECLARATION_LIST_P");
        List<String> DECLARATION_LIST_P2 = generateRule(""); // epsilon (empty)

        List<String> DECLARATION1 = generateRule("TYPE ID_LIST ;");
        List<String> DECLARATION2 = generateRule("ID_LIST ;");

        List<String> ID_LIST1 = generateRule("identifier ASSIGNMENT ID_LIST_P");
        List<String> ID_LIST_P1 = generateRule(", identifier ASSIGNMENT ID_LIST_P");
        List<String> ID_LIST_P2 = generateRule(""); // epsilon (empty)


        List<String> ASSIGNMENT1 = generateRule("= OP_STMT");
        List<String> ASSIGNMENT2 = generateRule("");


//        List<String> DECLARATION1 = generateRule("int OPERATOR ;");
//        List<String> DECLARATION2 = generateRule("integer OPERATOR ;");

//        List<String> VARIABLES = generateRule(", OPERATOR");

        //List<String> DECLARATIONS1 = generateRule("DECLARATION DECLARATIONS");

//        List<String> OPERATOR1 = generateRule("OP_STMT OPERATOR_P");

////        List<String> OPERATOR_P1 = generateRule("= OP_STMT");
//        List<String> OPERATOR_P2 = generateRule("");
//        List<String> OPERATOR_P3 = generateRule(", OPERATOR");

        List<String> OP_STMT1 = generateRule("TERM OP_STMT_P");

        List<String> OP_STMT_P1 = generateRule("+ TERM OP_STMT_P");
        List<String> OP_STMT_P2 = generateRule("++");
        List<String> OP_STMT_P3 = generateRule("");

        List<String> TERM1 = generateRule("FACTOR TERM_P");

        List<String> TERM_P1 = generateRule("* FACTOR TERM_P");
        List<String> TERM_P2 = generateRule("");

        List<String> FACTOR1 = generateRule("identifier");
        List<String> FACTOR2 = generateRule("number_literal");

        List<String> PRINT_CONTENT1 = generateRule("string_literal");
        List<String> PRINT_CONTENT2 = generateRule("identifier");

        List<String> IF_STMT1 = generateRule("if ( COM_STMT ) BEGIN_STMT IF_STMT_P");

        List<String> IF_STMT_P1 = generateRule("else_if ( COM_STMT ) BEGIN_STMT IF_STMT_P");
        List<String> IF_STMT_P2 = generateRule("else BEGIN_STMT");
        List<String> IF_STMT_P3 = generateRule("");

        List<String> PRINT1 = generateRule("print_line ( PRINT_CONTENT ) ;");
        List<String> PRINT2 = generateRule("display ( PRINT_CONTENT ) ;");

        List<String> WHILE_STMT1 = generateRule("while ( COM_STMT ) BEGIN_STMT");

        List<String> FOR_STMT1 = generateRule("for ( DECLARATION COM_STMT ; OP_STMT ) BEGIN_STMT");

        List<String> BREAK_STMT1 = generateRule("break ;");

        List<String> COM_STMT1 = generateRule("TERM COM_STMT_P");

        List<String> COM_STMT_P1 = generateRule("< FACTOR");
        List<String> COM_STMT_P2 = generateRule("== FACTOR");
        List<String> COM_STMT_P3 = generateRule("");


        HashMap<String, List<String>> S_Rules = new HashMap<>();
        S_Rules.put("program", S);
        parsingTable.put("S", S_Rules);

        HashMap<String, List<String>> BEGIN_BLOCK_Rules = new HashMap<>();
        BEGIN_BLOCK_Rules.put("program", BEGIN_BLOCK1);
        parsingTable.put("BEGIN_BLOCK", BEGIN_BLOCK_Rules);

        HashMap<String, List<String>> BEGIN_STMT_Rules = new HashMap<>();
        BEGIN_STMT_Rules.put("begin", BEGIN_STMT1);
        parsingTable.put("BEGIN_STMT", BEGIN_STMT_Rules);

        HashMap<String, List<String>> STMTS_Rules = new HashMap<>();
        STMTS_Rules.put("int", STMTS1);
        STMTS_Rules.put("integer", STMTS1);
        STMTS_Rules.put("identifier", STMTS1);
//        STMTS_Rules.put("number_literal", STMTS1);
        STMTS_Rules.put("if", STMTS1);
        STMTS_Rules.put("print_line", STMTS1);
        STMTS_Rules.put("display", STMTS1);
        STMTS_Rules.put("while", STMTS1);
        STMTS_Rules.put("for", STMTS1);
        STMTS_Rules.put("break", STMTS1);
        parsingTable.put("STMTS", STMTS_Rules);

        HashMap<String, List<String>> STMTS_P_Rules = new HashMap<>();
        STMTS_P_Rules.put("end", STMTS_P2);
        STMTS_P_Rules.put("int", STMTS_P1);
        STMTS_P_Rules.put("integer", STMTS_P1);
        STMTS_P_Rules.put("identifier", STMTS_P1);
//        STMTS_Rules.put("number_literal", STMTS1);
        STMTS_P_Rules.put("if", STMTS_P1);
        STMTS_P_Rules.put("print_line", STMTS_P1);
        STMTS_P_Rules.put("display", STMTS_P1);
        STMTS_P_Rules.put("while", STMTS_P1);
        STMTS_P_Rules.put("for", STMTS_P1);
        STMTS_P_Rules.put("break", STMTS_P1);
        parsingTable.put("STMTS_P", STMTS_P_Rules);

        HashMap<String, List<String>> STMT_Rules = new HashMap<>();
        STMT_Rules.put("int", STMT1);
        STMT_Rules.put("integer", STMT1);
        STMT_Rules.put("identifier", STMT1);
//        STMT_Rules.put("number_literal", STMT1);
        STMT_Rules.put("if", STMT2);
        STMT_Rules.put("print_line", STMT3);
        STMT_Rules.put("display", STMT3);
        STMT_Rules.put("while", STMT4);
        STMT_Rules.put("for", STMT5);
        STMT_Rules.put("break", STMT6);
        parsingTable.put("STMT", STMT_Rules);


        parsingTable.put("DECLARATION_LIST", new HashMap<>());
        parsingTable.get("DECLARATION_LIST").put("int", DECLARATION_LIST1);
        parsingTable.get("DECLARATION_LIST").put("integer", DECLARATION_LIST1);
        parsingTable.get("DECLARATION_LIST").put("identifier", DECLARATION_LIST1);
        parsingTable.get("DECLARATION_LIST").put(";", DECLARATION_LIST2);

        parsingTable.put("DECLARATION_LIST_P", new HashMap<>());
        parsingTable.get("DECLARATION_LIST_P").put(",", DECLARATION_LIST_P1);
        parsingTable.get("DECLARATION_LIST_P").put(")", DECLARATION_LIST_P2);
        parsingTable.get("DECLARATION_LIST_P").put(";", DECLARATION_LIST_P2);
        parsingTable.get("DECLARATION_LIST_P").put("if", DECLARATION_LIST_P2);
        parsingTable.get("DECLARATION_LIST_P").put("print_line", DECLARATION_LIST_P2);
        parsingTable.get("DECLARATION_LIST_P").put("display", DECLARATION_LIST_P2);
        parsingTable.get("DECLARATION_LIST_P").put("while", DECLARATION_LIST_P2);
        parsingTable.get("DECLARATION_LIST_P").put("for", DECLARATION_LIST_P2);
        parsingTable.get("DECLARATION_LIST_P").put("break", DECLARATION_LIST_P2);

        parsingTable.put("DECLARATION", new HashMap<>());
        parsingTable.get("DECLARATION").put("int", DECLARATION1);
        parsingTable.get("DECLARATION").put("integer", DECLARATION1);
        parsingTable.get("DECLARATION").put("identifier", DECLARATION2);

        HashMap<String, List<String>> ASSIGNMENT_Rules = new HashMap<>();
        ASSIGNMENT_Rules.put("=", ASSIGNMENT1);
        ASSIGNMENT_Rules.put(",", ASSIGNMENT2);
        ASSIGNMENT_Rules.put(";", ASSIGNMENT2);
        parsingTable.put("ASSIGNMENT", ASSIGNMENT_Rules);

        parsingTable.put("ID_LIST", new HashMap<>());
        parsingTable.get("ID_LIST").put("identifier", ID_LIST1);


        HashMap<String, List<String>> ID_LIST_P_Rules = new HashMap<>();
        ID_LIST_P_Rules.put(",", ID_LIST_P1);
        ID_LIST_P_Rules.put(";", ID_LIST_P2);     //??????????
//        DECLARATION_Rules.put("identifier", DECLARATION3);
//        DECLARATION_Rules.put("number_literal", DECLARATION3);
        parsingTable.put("ID_LIST_P", ID_LIST_P_Rules);

        HashMap<String, List<String>> TYPE_Rules = new HashMap<>();   // conflict
        TYPE_Rules.put("int", TYPE1);
        TYPE_Rules.put("integer", TYPE2);
        parsingTable.put("TYPE", TYPE_Rules);

//        HashMap<String, List<String>> OPERATOR_Rules = new HashMap<>();   // conflict
//        OPERATOR_Rules.put("identifier", OP_STMT1);
//        OPERATOR_Rules.put("number_literal", OP_STMT1);
//        parsingTable.put("OPERATOR", OPERATOR_Rules);

        HashMap<String, List<String>> PRINT_CONTENT_Rules = new HashMap<>();   // conflict
        PRINT_CONTENT_Rules.put("string_literal", PRINT_CONTENT1);
        PRINT_CONTENT_Rules.put("identifier", PRINT_CONTENT2);
        parsingTable.put("PRINT_CONTENT", PRINT_CONTENT_Rules);

//        HashMap<String, List<String>> OPERATOR_P_Rules = new HashMap<>();   // conflict
//        OPERATOR_P_Rules.put("=", OP_STMT1);
//        OPERATOR_P_Rules.put(";", OP);
//        OPERATOR_P_Rules.put(",", OPERATOR_P3);
//        parsingTable.put("OPERATOR_P", OPERATOR_P_Rules);

        HashMap<String, List<String>> OP_STMT_Rules = new HashMap<>();   // conflict
        OP_STMT_Rules.put("identifier", OP_STMT1);
        OP_STMT_Rules.put("number_literal", OP_STMT1);
        parsingTable.put("OP_STMT", OP_STMT_Rules);

        HashMap<String, List<String>> OP_STMT_P_Rules = new HashMap<>();   // conflict
        OP_STMT_P_Rules.put(";", OP_STMT_P3);
        OP_STMT_P_Rules.put(",", OP_STMT_P3);
        OP_STMT_P_Rules.put("=", OP_STMT_P3);
        OP_STMT_P_Rules.put(")", OP_STMT_P3);
        OP_STMT_P_Rules.put("++", OP_STMT_P2);
        OP_STMT_P_Rules.put("+", OP_STMT_P1);
        parsingTable.put("OP_STMT_P", OP_STMT_P_Rules);

        HashMap<String, List<String>> TERM_Rules = new HashMap<>();
        TERM_Rules.put("identifier", TERM1);
        TERM_Rules.put("number_literal", TERM1);
        parsingTable.put("TERM", TERM_Rules);

        HashMap<String, List<String>> TERM_P_Rules = new HashMap<>();
        TERM_P_Rules.put("*", TERM_P1);
        TERM_P_Rules.put(";", TERM_P2);
        TERM_P_Rules.put(",", TERM_P2);
        TERM_P_Rules.put("+", TERM_P2);
        TERM_P_Rules.put(")", TERM_P2);
        TERM_P_Rules.put("++", TERM_P2);
        TERM_P_Rules.put("=", TERM_P2);
        TERM_P_Rules.put("<", TERM_P2);
        TERM_P_Rules.put("==", TERM_P2);
        parsingTable.put("TERM_P", TERM_P_Rules);

        HashMap<String, List<String>> FACTOR_Rules = new HashMap<>();
        FACTOR_Rules.put("identifier", FACTOR1);
        FACTOR_Rules.put("number_literal", FACTOR2);
        parsingTable.put("FACTOR", FACTOR_Rules);

        HashMap<String, List<String>> IF_STMT_Rules = new HashMap<>();
        IF_STMT_Rules.put("if", IF_STMT1);
        parsingTable.put("IF_STMT", IF_STMT_Rules);

        HashMap<String, List<String>> IF_STMT_P_Rules = new HashMap<>();
        IF_STMT_P_Rules.put("else_if", IF_STMT_P1);
        IF_STMT_P_Rules.put("else", IF_STMT_P2);
        IF_STMT_P_Rules.put("end", IF_STMT_P3);
        IF_STMT_P_Rules.put(")", IF_STMT_P3);
        parsingTable.put("IF_STMT_P", IF_STMT_P_Rules);

        HashMap<String, List<String>> PRINT_STMT_Rules = new HashMap<>();
        PRINT_STMT_Rules.put("print_line", PRINT1);
        PRINT_STMT_Rules.put("display", PRINT2);
        parsingTable.put("PRINT_STMT", PRINT_STMT_Rules);

        HashMap<String, List<String>> WHILE_STMT_Rules = new HashMap<>();
        WHILE_STMT_Rules.put("while", WHILE_STMT1);
        parsingTable.put("WHILE_STMT", WHILE_STMT_Rules);

        HashMap<String, List<String>> FOR_STMT_Rules = new HashMap<>();
        FOR_STMT_Rules.put("for", FOR_STMT1);
        parsingTable.put("FOR_STMT", FOR_STMT_Rules);

        HashMap<String, List<String>> BREAK_STMT_Rules = new HashMap<>();
        BREAK_STMT_Rules.put("break", BREAK_STMT1);
        parsingTable.put("BREAK_STMT", BREAK_STMT_Rules);

        HashMap<String, List<String>> COM_STMT_Rules = new HashMap<>();
        COM_STMT_Rules.put("identifier", COM_STMT1);
        //COM_STMT_Rules.put("number_literal", COM_STMT1);
        parsingTable.put("COM_STMT", COM_STMT_Rules);

        HashMap<String, List<String>> COM_STMT_P_Rules = new HashMap<>();
        COM_STMT_P_Rules.put("<", COM_STMT_P1);
        COM_STMT_P_Rules.put("==", COM_STMT_P2);
        COM_STMT_P_Rules.put(")", COM_STMT_P3);
        parsingTable.put("COM_STMT_P", COM_STMT_P_Rules);

    }

    public void parseList(Token token_table) {
        table = Token.getTable();
        //table.add(0, new Token.TokenEntry("$", "dollar"));
        idx = 0;
        max_len = table.size();

        declared_variables = new ArrayList<>();
        generate_stack();
        generate_parsingTable();

        start_parser();
        //System.out.println(pass);
    }

    private Token.TokenEntry getToken() {
        if(idx > max_len - 1) {
            if(stack.pop().equals("$")) {
                //System.out.println("[MATCH] [" + top + ", " + token.getValue() + "]"/*+ stack.get(0) + ": " + token.getValue() + "] ["*/);
                System.out.println("Parse OK");
                System.exit(0);
            }
            error("index overbound");
        }
        if(table.get(idx).getTokenType().equals("comment")) {
            idx++;
            return getToken();
        }
        return table.get(idx);
    }


    /*
    set ip to point to the first symbol of w;
    set X to the top stack symbol;
    while ( X $ ) {  stack is not empty
        if( X is a ) pop the stack and advance ip;
        else if ( X is a terminal ) errorQ;
        else if ( M[X,a] is an error entry ) errorQ;
        else if ( M[X,a] = X -> YY •••Y) { X2k
                output the production X -> Y\Y • • • Y; 2k
                pop the stack;
                push Yk, Yfc-i,... ,Yi onto the stack, with Y\ on top;
        }
        set X to the top stack symbol;
    }
     */

    public void start_parser() {

        // check if stack is empty
        // check if pop is NT or T
        // match?
        token = getToken();
        int count = 0;

        while (!stack.empty()) { //while stack not empty
            //System.out.println(count++);
            String top = stack.pop(); // pop stack and advance
            //printStack(stack, "POP");
            //System.out.println(top + " " + token.getValue() + " " + token.getTokenType());
            //Token.TokenEntry token = getToken();
            //String first = parsingTable.get(top).get(token.getTokenType()).get(0);

            if(top.equals("$")) {
                if(token.getValue().equals("$")) {
                    System.out.println("EOS");
                    System.out.println("Parse OK");
                }
                else error(top);
            }

            if(token.getValue().equals(top) || token.getTokenType().equals(top)) {
                //matched
                System.out.println("[MATCH] - " + token.getTokenType().toUpperCase() + " - " + token.getValue());

                if(token.getValue().equals("int") || token.getValue().equals("integer")) {
                    idx++;
                    token = getToken();
                    declared_variables.add(token.getValue());
                }
                else {
                    idx++;
                    token = getToken();
                }

                if(token.getTokenType().equals("identifier")) {
                    int flag=0;
                    if(table.get(idx-1).getValue().equals(",")) {
                        flag=1;
                        declared_variables.add(token.getValue());
                    }
                    if(table.get(idx-1).getValue().equals("program")) flag=1;
                    else {
                        for(String i:declared_variables) {
                            if(token.getValue().equals(i)) {
                                flag=1;
                                break;
                            }
                        }
                    }
                    if(flag == 0) {
                        if(containsKeyword(token.getValue())) error("wrong keyword");
                        else error("not declared");
                    }
                }
                //printStack(stack, "MATCH");

            }
            else if (Character.isUpperCase(top.charAt(0))) { // non terminal - push on stack
                HashMap<String, List<String>> nt = parsingTable.get(top);
//                for (Map.Entry<String, List<String>> entry : nt.entrySet()) {
//                    String key = entry.getKey();
//                    List<String> values = entry.getValue();
//
//                    System.out.print("Key: " + key + " -> Values: ");
//                    for (String value : values) {
//                        System.out.print(value + " ");
//                    }
//                    System.out.println();
//                }
                if(nt.containsKey(token.getValue())) {
                    //System.out.println("found " + token.getValue());
                    List<String> l = nt.get(token.getValue());
                    for (int i = l.size() - 1; i >= 0; i--) {
                        if(l.get(i).isEmpty()) {
                            //idx++;
                            break;
                        }
                        stack.push(l.get(i));
                    }
                    printStack(stack, "GENERATE-stack");
                }
                else if(nt.containsKey(token.getTokenType())) {
                    List<String> l = nt.get(token.getTokenType());

                    for (int i = l.size() - 1; i >= 0; i--) {
                        if(l.get(i).isEmpty()) {
                            //idx++;
                            break;
                        }
                        stack.push(l.get(i));
                    }
                    printStack(stack, "GENERATE-stack");
                }
            }
            else {
                error(top);
            }
        }

    }

    public void error(String top) {
        if(top.equals("index overbound")) System.out.println("ERROR: Parsing stack is empty." +
                "\nKeyword " + token.getValue() + " not matched.");
        else if (top.equals("not declared")) System.out.println("ERROR: " +token.getValue() + " " + top);
        else if (top.equals("wrong keyword")) System.out.println("ERROR: keyword \'" + token.getValue() + "\' spelling error.");
        else System.out.println("ERROR: expected " + top + ", got " + token.getValue() + " " + token.getTokenType());
        System.out.println("Parsing failed.");
        System.exit(0);
    }

    public void printStack(Stack<String> stack, String action) {
        System.out.print("[" + action + "] [" /*+ stack.get(0) + ": " + token.getValue() + "] ["*/);

        for (int i=0; i< stack.size(); i++) {
            System.out.print(stack.get(i));
            if(i!=stack.size()-1) System.out.print( ", ");
        }
        System.out.println("]");
    }

//    public boolean isTerminal (String s) {
//
//    }

    public boolean containsKeyword(String s) {
        for(String i:ExpandIdentifier.keywords){
            if(s.contains(i)) return true;
        }
        return false;
    }

}
